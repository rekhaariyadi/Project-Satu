export const NavbarItems = [
    {
        title:'Get Cv',
        url:"#",
        cName: 'nav-links'
    },
]
