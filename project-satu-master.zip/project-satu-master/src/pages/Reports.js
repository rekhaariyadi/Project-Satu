import React from 'react'
import Navbar from '../components/Navbar/Navbar';

function Reports() {
    return (
        <div>
            <Navbar/>
            <div className='reports'>
                <h1>Reports</h1>
            </div>
        </div>
    )
}

export default Reports;
