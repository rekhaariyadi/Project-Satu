import React from 'react'
import Navbar from '../components/Navbar/Navbar';

function Products() {
    return (
        <div>
            <Navbar/>
            <div className='products'>
                <h1>Products</h1>
            </div>
        </div>
    )
}

export default Products;
